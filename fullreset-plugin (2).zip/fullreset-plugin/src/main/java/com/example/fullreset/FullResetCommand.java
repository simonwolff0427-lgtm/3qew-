package com.example.fullreset;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.ArrayList;
import java.util.List;

public class FullResetCommand implements CommandExecutor, TabCompleter {

    private final FullResetPlugin plugin;
    private final ResetManager resetManager;

    public FullResetCommand(FullResetPlugin plugin, ResetManager resetManager) {
        this.plugin = plugin;
        this.resetManager = resetManager;
    }

    private String msg(String key) {
        return plugin.getConfig().getString("messages.prefix", "") +
                plugin.getConfig().getString("messages." + key, key);
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("fullreset.admin")) {
            sender.sendMessage(color(msg("no-permission")));
            return true;
        }

        if (args.length == 0) {
            sender.sendMessage(color("&eUsage: /fullreset <request|confirm|cancel>"));
            return true;
        }

        String sub = args[0].toLowerCase();
        switch (sub) {
            case "request" -> {
                int timeout = plugin.getConfig().getInt("options.confirmation-timeout-seconds", 30);
                boolean started = resetManager.requestReset(sender);
                if (started) {
                    sender.sendMessage(color(msg("need-confirm").replace("{timeout}", String.valueOf(timeout))));
                } else {
                    sender.sendMessage(color("&7A reset request is already pending. Use /fullreset confirm or /fullreset cancel."));
                }
            }
            case "confirm" -> {
                boolean ok = resetManager.confirmReset(sender);
                if (!ok) {
                    sender.sendMessage(color(msg("nothing-pending")));
                }
            }
            case "cancel" -> {
                boolean ok = resetManager.cancelPending();
                sender.sendMessage(color(ok ? msg("cancelled") : msg("nothing-pending")));
            }
            default -> sender.sendMessage(color("&eUsage: /fullreset <request|confirm|cancel>"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : new String[]{"request", "confirm", "cancel"}) {
                if (s.startsWith(args[0].toLowerCase())) out.add(s);
            }
        }
        return out;
    }
}
