package com.example.fullreset;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.WorldType;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.FileVisitResult;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Random;
import java.util.concurrent.CompletableFuture;

/**
 * Handles the full lifecycle of a server reset:
 *   1) confirmation window
 *   2) countdown + kick
 *   3) unload + delete world folders
 *   4) regenerate worlds with fresh random seeds
 *   5) clear saved homes (EssentialsX userdata, if present)
 *
 * Deliberately does NOT touch: plugins/LuckPerms, plugins/WorldGuard, or any
 * spawn-protection settings — those live entirely outside the world folders
 * this plugin deletes, and this plugin never reads or writes those paths.
 */
public class ResetManager {

    private final FullResetPlugin plugin;
    private boolean pending = false;
    private BukkitTask expiryTask;
    private boolean resetInProgress = false;

    public ResetManager(FullResetPlugin plugin) {
        this.plugin = plugin;
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    private String prefixed(String key) {
        return plugin.getConfig().getString("messages.prefix", "") + plugin.getConfig().getString("messages." + key, key);
    }

    public boolean requestReset(CommandSender initiator) {
        if (pending || resetInProgress) {
            return false;
        }
        pending = true;
        int timeout = plugin.getConfig().getInt("options.confirmation-timeout-seconds", 30);
        expiryTask = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (pending) {
                pending = false;
                initiator.sendMessage(color(prefixed("expired")));
            }
        }, timeout * 20L);
        return true;
    }

    public boolean confirmReset(CommandSender initiator) {
        if (!pending) {
            return false;
        }
        pending = false;
        if (expiryTask != null) {
            expiryTask.cancel();
            expiryTask = null;
        }
        initiator.sendMessage(color(prefixed("confirmed")));
        beginCountdownAndReset();
        return true;
    }

    public boolean cancelPending() {
        if (!pending) {
            return false;
        }
        pending = false;
        if (expiryTask != null) {
            expiryTask.cancel();
            expiryTask = null;
        }
        return true;
    }

    // ---------------------------------------------------------------
    // Countdown -> kick -> reset
    // ---------------------------------------------------------------

    private void beginCountdownAndReset() {
        resetInProgress = true;
        int seconds = plugin.getConfig().getInt("options.countdown-seconds", 15);
        String startMsg = color(prefixed("broadcast-start").replace("{seconds}", String.valueOf(seconds)));
        Bukkit.broadcastMessage(startMsg);

        tickCountdown(seconds);
    }

    private void tickCountdown(int secondsLeft) {
        if (secondsLeft <= 0) {
            kickAllAndReset();
            return;
        }
        if (secondsLeft <= 5 || secondsLeft % 5 == 0) {
            Bukkit.broadcastMessage(color(prefixed("broadcast-tick").replace("{seconds}", String.valueOf(secondsLeft))));
        }
        Bukkit.getScheduler().runTaskLater(plugin, () -> tickCountdown(secondsLeft - 1), 20L);
    }

    private void kickAllAndReset() {
        String kickMsg = color(prefixed("kick-message"));
        for (Player p : Bukkit.getOnlinePlayers().toArray(new Player[0])) {
            p.kickPlayer(kickMsg);
        }
        // Temporarily whitelist-lock joins during the reset so nobody connects mid-wipe.
        boolean wasWhitelisted = Bukkit.hasWhitelist();
        Bukkit.setWhitelist(true);

        // Poll until everyone has actually finished disconnecting (kicking is not
        // instantaneous — the player list can still be non-empty for a few ticks
        // after kickPlayer() is called), instead of assuming a fixed delay is enough.
        waitForEmptyThenReset(wasWhitelisted, 0);
    }

    private void waitForEmptyThenReset(boolean restoreWhitelist, int attempt) {
        if (!Bukkit.getOnlinePlayers().isEmpty() && attempt < 200) { // up to ~10s
            Bukkit.getScheduler().runTaskLater(plugin, () -> waitForEmptyThenReset(restoreWhitelist, attempt + 1), 1L);
            return;
        }
        doReset(restoreWhitelist);
    }

    // ---------------------------------------------------------------
    // Actual reset
    // ---------------------------------------------------------------

    private void doReset(boolean restoreWhitelist) {
        var cfg = plugin.getConfig();
        String overworldName = cfg.getString("worlds.overworld", "world");
        String netherName = cfg.getString("worlds.nether", "world_nether");
        String endName = cfg.getString("worlds.the_end", "world_the_end");

        boolean doOverworld = cfg.getBoolean("options.reset-overworld", true);
        boolean doNether = cfg.getBoolean("options.reset-nether", true);
        boolean doEnd = cfg.getBoolean("options.reset-end", true);
        boolean randomizeSeeds = cfg.getBoolean("options.randomize-seeds", true);

        long overworldSeed = randomizeSeeds ? new Random().nextLong() : currentSeedOrRandom(overworldName);
        long netherSeed = randomizeSeeds ? new Random().nextLong() : currentSeedOrRandom(netherName);
        long endSeed = randomizeSeeds ? new Random().nextLong() : currentSeedOrRandom(endName);

        // 1) Unload worlds and CONFIRM they actually unloaded before doing anything
        //    destructive. unloadWorld() can silently return false (e.g. if Bukkit still
        //    thinks a player/entity is attached) — if we don't check that, we'd delete
        //    files out from under a still-loaded world and then WorldCreator would just
        //    hand back the same old in-memory world instead of a fresh one, with no error.
        java.util.List<String> toUnload = new java.util.ArrayList<>();
        if (doOverworld) toUnload.add(overworldName);
        if (doNether) toUnload.add(netherName);
        if (doEnd) toUnload.add(endName);

        unloadAllWithRetry(toUnload, 0, () -> {
            java.util.List<String> stillLoaded = toUnload.stream()
                    .filter(n -> Bukkit.getWorld(n) != null)
                    .toList();

            if (!stillLoaded.isEmpty()) {
                Bukkit.broadcastMessage(color("&c&lReset ABORTED — could not unload: " + stillLoaded
                        + ". No files were touched. Try again, or restart the server and retry."));
                plugin.getLogger().severe("Reset aborted: worlds would not unload: " + stillLoaded);
                Bukkit.setWhitelist(restoreWhitelist);
                resetInProgress = false;
                return;
            }

            // 2) Delete folders off the main thread (pure disk I/O).
            CompletableFuture.runAsync(() -> {
                if (doOverworld) deleteWorldFolder(overworldName);
                if (doNether) deleteWorldFolder(netherName);
                if (doEnd) deleteWorldFolder(endName);
            }).thenRun(() -> Bukkit.getScheduler().runTask(plugin, () -> {
                // 3) Recreate worlds on the main thread.
                if (doOverworld) {
                    new WorldCreator(overworldName)
                            .environment(World.Environment.NORMAL)
                            .type(WorldType.NORMAL)
                            .seed(overworldSeed)
                            .createWorld();
                }
                if (doNether) {
                    new WorldCreator(netherName)
                            .environment(World.Environment.NETHER)
                            .seed(netherSeed)
                            .createWorld();
                }
                if (doEnd) {
                    new WorldCreator(endName)
                            .environment(World.Environment.THE_END)
                            .seed(endSeed)
                            .createWorld();
                }

                // 4) Homes / economy / kits / etc. inside EssentialsX userdata.
                if (cfg.getBoolean("options.reset-homes", true)) {
                    clearEssentialsKeys();
                }

                // 5) Anything else the server owner listed: AH data, shop/order data,
                //    economy plugin folders, etc.
                wipeExtraDataPaths();

                // 6) Restore whitelist state and announce.
                Bukkit.setWhitelist(restoreWhitelist);
                String done = prefixed("broadcast-done")
                        .replace("{overworld_seed}", String.valueOf(overworldSeed))
                        .replace("{nether_seed}", String.valueOf(netherSeed))
                        .replace("{end_seed}", String.valueOf(endSeed));
                Bukkit.broadcastMessage(color(done));
                plugin.getLogger().info("Full reset complete. Seeds -> overworld=" + overworldSeed
                        + " nether=" + netherSeed + " end=" + endSeed);

                resetInProgress = false;
            }));
        });
    }

    /**
     * Attempts to unload every world in {@code names}, retrying any that fail (up to
     * ~5s total) before giving up and calling {@code after} regardless of outcome —
     * the caller checks which worlds are still loaded and aborts loudly if any are.
     */
    private void unloadAllWithRetry(java.util.List<String> names, int attempt, Runnable after) {
        boolean anyStillLoaded = false;
        for (String name : names) {
            World w = Bukkit.getWorld(name);
            if (w != null) {
                boolean ok = Bukkit.unloadWorld(w, false);
                if (!ok) anyStillLoaded = true;
            }
        }
        if (anyStillLoaded && attempt < 100) { // up to ~5s of retries
            Bukkit.getScheduler().runTaskLater(plugin, () -> unloadAllWithRetry(names, attempt + 1, after), 1L);
            return;
        }
        after.run();
    }

    private long currentSeedOrRandom(String worldName) {
        World w = Bukkit.getWorld(worldName);
        return (w != null) ? w.getSeed() : new Random().nextLong();
    }

    private void deleteWorldFolder(String worldName) {
        Path worldPath = new File(Bukkit.getWorldContainer(), worldName).toPath();
        if (!Files.exists(worldPath)) return;
        try {
            deleteDirectoryRecursively(worldPath);
        } catch (IOException e) {
            plugin.getLogger().warning("Failed to fully delete world folder '" + worldName + "': " + e.getMessage());
        }
    }

    /**
     * Strips the configured top-level keys (default: just "homes") out of every
     * EssentialsX userdata YAML file, if the Essentials userdata folder exists. This
     * edits the YAML directly and does not require Essentials as a dependency, and
     * touches nothing outside the listed keys (e.g. leaves the player's UUID/username
     * mapping, and any key you didn't list, alone).
     */
    private void clearEssentialsKeys() {
        var cfg = plugin.getConfig();
        String path = cfg.getString("options.essentials-userdata-path", "plugins/Essentials/userdata");
        java.util.List<String> keys = cfg.getStringList("options.essentials-clear-keys");
        if (keys.isEmpty()) keys = java.util.List.of("homes");

        File dir = new File(plugin.getServer().getWorldContainer().getParentFile(), path);
        if (!dir.isDirectory()) {
            return; // Essentials not installed / no userdata yet — nothing to do.
        }
        File[] files = dir.listFiles((d, name) -> name.toLowerCase().endsWith(".yml"));
        if (files == null) return;

        int cleared = 0;
        for (File f : files) {
            try {
                YamlConfiguration yaml = YamlConfiguration.loadConfiguration(f);
                boolean changed = false;
                for (String key : keys) {
                    if (yaml.contains(key)) {
                        yaml.set(key, null);
                        changed = true;
                    }
                }
                if (changed) {
                    yaml.save(f);
                    cleared++;
                }
            } catch (IOException e) {
                plugin.getLogger().warning("Could not clear data in " + f.getName() + ": " + e.getMessage());
            }
        }
        plugin.getLogger().info("Cleared " + keys + " for " + cleared + " player file(s).");
    }

    /**
     * Deletes every path listed under options.extra-data-paths in config.yml, relative
     * to the server root (the folder server.jar lives in). This is how auction house
     * listings, shop/order data, economy plugin folders, etc. get wiped — it's fully
     * config-driven so it only ever touches what the server owner explicitly listed.
     * Each entry can be a single file or a whole folder.
     */
    private void wipeExtraDataPaths() {
        java.util.List<String> paths = plugin.getConfig().getStringList("extra-data-paths");
        if (paths.isEmpty()) return;

        File serverRoot = plugin.getServer().getWorldContainer().getParentFile();
        for (String rel : paths) {
            File target = new File(serverRoot, rel);
            if (!target.exists()) {
                plugin.getLogger().info("extra-data-paths: '" + rel + "' does not exist, skipping.");
                continue;
            }
            try {
                if (target.isDirectory()) {
                    deleteDirectoryRecursively(target.toPath());
                } else {
                    Files.delete(target.toPath());
                }
                plugin.getLogger().info("extra-data-paths: deleted '" + rel + "'.");
            } catch (IOException e) {
                plugin.getLogger().warning("Failed to delete extra data path '" + rel + "': " + e.getMessage());
            }
        }
    }

    private void deleteDirectoryRecursively(Path dirPath) throws IOException {
        Files.walkFileTree(dirPath, new SimpleFileVisitor<>() {
            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                Files.delete(file);
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
                Files.delete(dir);
                return FileVisitResult.CONTINUE;
            }
        });
    }
}
