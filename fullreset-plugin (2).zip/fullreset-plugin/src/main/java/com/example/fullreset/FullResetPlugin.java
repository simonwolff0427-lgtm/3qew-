package com.example.fullreset;

import org.bukkit.plugin.java.JavaPlugin;

public final class FullResetPlugin extends JavaPlugin {

    private static FullResetPlugin instance;
    private ResetManager resetManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        this.resetManager = new ResetManager(this);

        FullResetCommand executor = new FullResetCommand(this, resetManager);
        var command = getCommand("fullreset");
        if (command != null) {
            command.setExecutor(executor);
            command.setTabCompleter(executor);
        }

        getLogger().info("FullReset enabled. Use /fullreset request to begin a full wipe.");
    }

    @Override
    public void onDisable() {
        if (resetManager != null) {
            resetManager.cancelPending();
        }
        getLogger().info("FullReset disabled.");
    }

    public static FullResetPlugin getInstance() {
        return instance;
    }

    public ResetManager getResetManager() {
        return resetManager;
    }
}
