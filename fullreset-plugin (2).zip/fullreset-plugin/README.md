# FullReset — Paper 1.21.8 plugin

Built and configured for **Paper 1.21.8**, with the overworld set to your world's actual
level-name: `paper_1_21_8_3090309_h7sbinas` (nether/end default to Paper's standard
`_nether` / `_the_end` suffixes on that name — open `config.yml` and double-check these
against your actual world folder names before running a reset).

Wipes the server back to a clean slate:

- Deletes and regenerates the **Overworld, Nether, and End** with brand new random seeds
- Because inventories, ender chests, stats, and advancements are all stored as files
  *inside* those world folders (`playerdata/`, `stats/`, `advancements/`), deleting the
  worlds wipes them for **every player, online or offline** — no per-player API calls needed
- Clears whatever EssentialsX userdata keys you list in config (`homes` by default —
  add `money`, `kits`, `mails`, `nickname`, etc. if you want those wiped too). Only the
  keys you list are touched; everything else in those files is left alone
- Wipes **anything else you list** under `extra-data-paths` in config — this is how you
  cover auction house listings, shop/marketplace/order data, and any other plugin's
  saved data. It's config-driven: nothing gets touched unless you explicitly list its
  file/folder path

## Covering your auction house / shop / order plugins

Plugin data storage varies a lot between AH and shop plugins, so this is handled
generically: open `config.yml` and list the exact file(s) or folder(s) that plugin
stores its data in, under `extra-data-paths`. Common examples are already there as
commented-out lines — uncomment the ones that match what you run, or add your own.

To find the right path for a plugin you don't see listed: stop the server, look inside
`plugins/<PluginName>/`, and find whichever file changes when someone lists an item /
places an order (often `data.yml`, `listings.yml`, a `.db` file, or a `data/` subfolder).
List that specific file/folder rather than the whole plugin folder if you want to keep
that plugin's general config intact.

## What it deliberately never touches

- `plugins/LuckPerms/**` — permissions/groups are completely untouched
- `plugins/WorldGuard/**` — region definitions are untouched, **including your `spawn`
  region**. This plugin never reads or writes anything in that folder, so `spawn`'s
  boundaries and flags survive a reset exactly as they were
- Spawn protection / spawn-point plugin config — untouched
- Bans, whitelist entries (the whitelist is only toggled *on* during the reset window to
  block joins mid-wipe, then restored to whatever it was before), OP list, and any other
  plugin's data

**One caveat to be aware of:** WorldGuard regions are keyed partly to the world. If you
keep WorldGuard installed and regenerate the Overworld under the same name, most setups
will just re-attach fine on next load — but if you see region weirdness after a reset,
that's WorldGuard reconciling itself with a brand-new world instance, not this plugin
touching WorldGuard's files.

## Commands

| Command | Permission | Effect |
|---|---|---|
| `/fullreset request` | `fullreset.admin` (default: op) | Starts a confirmation window (30s by default) |
| `/fullreset confirm` | `fullreset.admin` | Confirms — triggers a countdown, then kicks everyone and wipes |
| `/fullreset cancel` | `fullreset.admin` | Cancels a pending request before it's confirmed |

Nothing happens from a single command — it always requires `request` **then** `confirm`,
so it's very hard to trigger by accident.

## Config (`config.yml`)

```yaml
worlds:
  overworld: world
  nether: world_nether
  the_end: world_the_end

options:
  reset-overworld: true
  reset-nether: true
  reset-end: true
  randomize-seeds: true
  reset-homes: true
  essentials-userdata-path: "plugins/Essentials/userdata"
  confirmation-timeout-seconds: 30
  countdown-seconds: 15
```

Turn any of `reset-overworld` / `reset-nether` / `reset-end` off if you want to keep one
dimension. Set `randomize-seeds: false` to wipe-and-regenerate with the *same* seed
instead of a new one.

## Building the jar (via GitHub Actions — no local tools needed)

This project includes `.github/workflows/build.yml`, which builds the jar for you
automatically using GitHub's servers. To use it:

1. Create a new **GitHub repository** (public or private, doesn't matter) — e.g. at
   github.com/new.
2. Push this whole `fullreset-plugin` folder to it:
   ```bash
   cd fullreset-plugin
   git init
   git add .
   git commit -m "FullReset plugin"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
   git push -u origin main
   ```
3. On GitHub, open your repo → the **Actions** tab. You'll see a "Build FullReset
   plugin" run kick off automatically (takes ~1 minute).
4. Click into that run → scroll to **Artifacts** → download `FullReset-jar`. Unzip it
   and you'll have `FullReset-1.0.0.jar`.
5. Drop that jar into your server's `plugins/` folder and restart.

Optional: if you also push a version tag (`git tag v1.0.0 && git push origin v1.0.0`),
the workflow will additionally create a proper GitHub **Release** with the jar attached,
so you get a stable, permanent download link instead of a build artifact.

### Alternative: build locally instead

If you'd rather not use GitHub, you only need a JDK 21 and Maven installed:
```bash
cd fullreset-plugin
mvn clean package
```
Output lands at `target/FullReset-1.0.0.jar`.

## Notes on safety

- The reset is **not undoable** — there's no backup step built in. If you want a safety
  net, back up your `world`, `world_nether`, `world_the_end`, and `plugins/Essentials`
  folders before running it, especially the first time.
- World deletion happens a few ticks after players are kicked, so their auto-save on
  disconnect can't "resurrect" old data — order is: kick → brief delay → delete → regenerate.
- Regeneration happens on the main thread (as Bukkit requires), but the actual folder
  deletion runs off-thread so it doesn't block the server during the I/O-heavy part.
